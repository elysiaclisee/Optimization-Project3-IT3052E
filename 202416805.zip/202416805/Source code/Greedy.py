from collections import defaultdict, deque

lines = []
try:
    while True:
        line = input()
        if line.strip() == "":
            break
        lines.append(line)
except EOFError:
    pass

idx = 0
n, q = map(int, lines[idx].split()); idx += 1

pre = []
for _ in range(q):
    u, v = map(int, lines[idx].split())
    pre.append((u - 1, v - 1))
    idx += 1

dur = list(map(int, lines[idx].split())); idx += 1
m = int(lines[idx]); idx += 1
avail = list(map(int, lines[idx].split())); idx += 1
k = int(lines[idx]); idx += 1

cost = defaultdict(lambda: 0)
can_do = [[] for _ in range(n)]
for _ in range(k):
    i, j, c = map(int, lines[idx].split())
    i -= 1; j -= 1
    cost[(i, j)] = c
    can_do[i].append(j)
    idx += 1

blocked = set(i for i in range(n) if not can_do[i])
queue = deque(blocked)
while queue:
    i = queue.popleft()
    for u, v in pre:
        if u == i and v not in blocked:
            blocked.add(v)
            queue.append(v)

pre_map = [[] for _ in range(n)]
for u, v in pre:
    pre_map[v].append(u)

done = set()
done_time = [0] * n
res = {}

while len(done) < n - len(blocked):
    ready = [
        i for i in range(n)
        if i not in done and i not in blocked and all(u in done for u in pre_map[i])
    ]
    if not ready:
        break

    ready.sort(key=lambda i: -dur[i])

    for i in ready:
        teams = can_do[i]
        if not teams:
            continue

        prereq_done = max((done_time[u] for u in pre_map[i]), default=0)
        j = min(teams, key=lambda t: (max(avail[t], prereq_done), cost[(i, t)]))
        st = max(avail[j], prereq_done)
        et = st + dur[i]

        res[i] = (j, st)
        avail[j] = et
        done_time[i] = et
        done.add(i)

print(len(res))
for i in sorted(res):
    j, st = res[i]
    print(i + 1, j + 1, st)
