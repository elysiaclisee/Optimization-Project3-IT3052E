from ortools.sat.python import cp_model
from collections import defaultdict

lines = []
try:
    while True:
        line = input()
        if line.strip() == "":
            break
        lines.append(line)
except EOFError:
    pass

idx = 0
n, q = map(int, lines[idx].split()); idx += 1
pre = [tuple(map(int, lines[idx + i].split())) for i in range(q)]; idx += q
dur = list(map(int, lines[idx].split())); idx += 1
m = int(lines[idx]); idx += 1
avail = list(map(int, lines[idx].split())); idx += 1
k = int(lines[idx]); idx += 1

cost = defaultdict(lambda: float('inf'))
can_do = [[] for _ in range(n)]

for i in range(k):
    t, tm, c = map(int, lines[idx + i].split())
    t -= 1
    tm -= 1
    cost[(t, tm)] = c
    can_do[t].append(tm)

blocked = set()
for i in range(n):
    if not can_do[i]:
        blocked.add(i)

model = cp_model.CpModel()
hz = sum(dur) + max(avail)

s = [None if i in blocked else model.NewIntVar(0, hz, f's_{i}') for i in range(n)]
p = [None if i in blocked else model.NewBoolVar(f'p_{i}') for i in range(n)]

x = {}
intervals = [[] for _ in range(m)]

for i in range(n):
    if i in blocked:
        continue
    for j in can_do[i]:
        x[(i, j)] = model.NewBoolVar(f'x_{i}_{j}')

for i in range(n):
    if i in blocked:
        continue
    model.Add(sum(x[(i, j)] for j in can_do[i]) == p[i])
    for j in can_do[i]:
        model.Add(s[i] >= avail[j]).OnlyEnforceIf(x[(i, j)])

for u, v in pre:
    u -= 1
    v -= 1
    if u in blocked or v in blocked:
        continue
    model.Add(s[v] >= s[u] + dur[u]).OnlyEnforceIf([p[u], p[v]])

for i in range(n):
    if i in blocked:
        continue
    for j in can_do[i]:
        iv = model.NewOptionalIntervalVar(s[i], dur[i], s[i] + dur[i], x[(i, j)], f'i_{i}_{j}')
        intervals[j].append(iv)

for j in range(m):
    model.AddNoOverlap(intervals[j])

ms = model.NewIntVar(0, hz, 'ms')
for i in range(n):
    if i in blocked:
        continue
    model.Add(ms >= s[i] + dur[i]).OnlyEnforceIf(p[i])

tc = sum(cost[(i, j)] * x[(i, j)] for i in range(n) if i not in blocked for j in can_do[i])
model.Maximize(sum(p[i] for i in range(n) if i not in blocked) * 1000000 - ms * 1000 - tc)

solver = cp_model.CpSolver()
solver.parameters.max_time_in_seconds = 60.0
stat = solver.Solve(model)

if stat not in [cp_model.OPTIMAL, cp_model.FEASIBLE]:
    print(0)
else:
    res = []
    for i in range(n):
        if i in blocked:
            continue
        if solver.Value(p[i]):
            for j in can_do[i]:
                if solver.Value(x[(i, j)]):
                    res.append((i + 1, j + 1, solver.Value(s[i])))
                    break
    print(len(res))
    for r in sorted(res):
        print(*r)
