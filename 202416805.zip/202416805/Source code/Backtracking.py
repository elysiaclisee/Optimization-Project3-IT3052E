#PYTHON 
from collections import defaultdict, deque
import time

lines = []
try:
    while True:
        line = input()
        if line.strip() == "":
            break
        lines.append(line)
except EOFError:
    pass

idx = 0
n, q = map(int, lines[idx].split()); idx += 1
pre = []
for _ in range(q):
    u, v = map(int, lines[idx].split())
    pre.append((u - 1, v - 1))
    idx += 1

dur = list(map(int, lines[idx].split())); idx += 1
m = int(lines[idx]); idx += 1
avail = list(map(int, lines[idx].split())); idx += 1
k = int(lines[idx]); idx += 1

cost = defaultdict(lambda: float('inf'))
can_do = [[] for _ in range(n)]
for _ in range(k):
    i, j, c = map(int, lines[idx].split())
    i -= 1; j -= 1
    cost[(i, j)] = c
    can_do[i].append(j)
    idx += 1

blocked = set(i for i in range(n) if not can_do[i])
queue = deque(blocked)
while queue:
    i = queue.popleft()
    for u, v in pre:
        if u == i and v not in blocked:
            blocked.add(v)
            queue.append(v)

pre_map = [[] for _ in range(n)]
for u, v in pre:
    if u not in blocked and v not in blocked:
        pre_map[v].append(u)

done = set()
order = []
while len(order) < n - len(blocked):
    ready = [i for i in range(n) if i not in done and i not in blocked and all(u in done for u in pre_map[i])]
    if not ready:
        break
    ready.sort()
    for i in ready:
        done.add(i)
        order.append(i)

best = []
bscore = (-1, float('inf'), float('inf'))
busy = [[] for _ in range(m)]
sched = []

start_time = time.time()

def backtrack(idx, cnt, ms, total_cost):
    global best, bscore
    if time.time() - start_time > 0.5:
        return
    if idx == len(order):
        score = (cnt, -ms, -total_cost)
        if score > bscore:
            best[:] = list(sched)
            bscore = score
        return

    i = order[idx]
    pre_end = max((s + dur[t] for t, _, s in sched if t in pre_map[i]), default=0)

    for j in sorted(can_do[i], key=lambda x: (cost[(i, x)], avail[x])):
        st = max(pre_end, avail[j])
        et = st + dur[i]
        if all(et <= s or st >= e for s, e in busy[j]):
            busy[j].append((st, et))
            sched.append((i, j, st))
            backtrack(idx + 1, cnt + 1, max(ms, et), total_cost + cost[(i, j)])
            sched.pop()
            busy[j].pop()

    backtrack(idx + 1, cnt, ms, total_cost)

backtrack(0, 0, 0, 0)

print(len(best))
for i, j, st in sorted(best):
    print(i + 1, j + 1, st)
